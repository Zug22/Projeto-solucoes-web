#!/bin/bash

echo "🛑 Limpando processos antigos..."
# Mata qualquer coisa rodando nas portas do projeto
sudo fuser -k 5000/tcp > /dev/null 2>&1
sudo fuser -k 5502/tcp > /dev/null 2>&1
sudo killall python python3 > /dev/null 2>&1

echo "🚀 Iniciando o EduGestor..."

# 1. Garante que o MongoDB está rodando
echo "Checking MongoDB..."
sudo systemctl start mongod

# 2. Inicia o Backend (Porta 5000)
echo "🐍 Subindo o Backend..."
cd backend
source venv/bin/activate
python app.py > /dev/null 2>&1 &
BACKEND_PID=$!
echo "✅ Backend rodando (PID: $BACKEND_PID)"

# 3. Inicia o Frontend (Porta 5502 - a que funcionou)
cd ../frontend
echo "🎨 Subindo o Frontend..."
python3 -m http.server 5502 > /dev/null 2>&1 &
FRONTEND_PID=$!
echo "✅ Frontend rodando na porta 5502 (PID: $FRONTEND_PID)"

# 4. Abre o navegador na Landing Page
sleep 3
xdg-open "http://localhost:5502/index.html"

echo ""
echo "==================================================="
echo "   🟢 SISTEMA NO AR! Pressione [ENTER] para parar."
echo "==================================================="
read

# 5. Limpeza Final
echo "🛑 Parando servidores..."
kill $BACKEND_PID
kill $FRONTEND_PID
sudo fuser -k 5000/tcp > /dev/null 2>&1
sudo fuser -k 5502/tcp > /dev/null 2>&1
echo "Tchau! 👋"
