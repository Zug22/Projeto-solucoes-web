// ========== PORTAL DO PROFESSOR - INTEGRAÇÃO FINAL ==========

// 1. SEGURANÇA: Verifica login antes de carregar qualquer coisa
const token = localStorage.getItem('token');
if (!token) {
    window.location.href = 'professor-login.html';
}

const API_URL = "http://127.0.0.1:5000/api";

document.addEventListener('DOMContentLoaded', function() {
  
  // ============================================================
  // PARTE 1: VISUAL E INTERFACE (MANTIDO DO ORIGINAL)
  // ============================================================

  // --- SISTEMA DE TEMA ---
  function initTheme() {
    const savedTheme = localStorage.getItem('theme');
    let theme = savedTheme;
    if (!savedTheme) {
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      theme = prefersDark ? 'dark' : 'light';
    }
    document.documentElement.setAttribute('data-theme', theme);
    updateThemeIcon(theme);
  }

  function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeIcon(newTheme);
  }

  function updateThemeIcon(theme) {
    const themeIcon = document.getElementById('themeIcon');
    if (themeIcon) themeIcon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
  }

  initTheme();
  const themeToggle = document.getElementById('themeToggle');
  if (themeToggle) themeToggle.addEventListener('click', toggleTheme);

  // --- SIDEBAR MOBILE ---
  const menuToggle = document.getElementById('menuToggle');
  const sidebar = document.getElementById('sidebar');
  if (menuToggle) {
    menuToggle.addEventListener('click', () => sidebar.classList.toggle('collapsed'));
  }

  // --- NAVEGAÇÃO (ABAS) ---
  const navItems = document.querySelectorAll('.nav-item[data-page], .quick-card[data-page]');
  const pageContents = document.querySelectorAll('.page-content');
  const pageTitle = document.getElementById('pageTitle');
  
  const pageTitles = {
    dashboard: 'Dashboard',
    alunos: 'Alunos Cadastrados',
    'cadastrar-aluno': 'Cadastrar Novo Aluno',
    'lancar-notas': 'Lançar Notas',
    'consultar-notas': 'Consultar Notas',
    faltas: 'Controle de Faltas'
  };

  function navigateToPage(pageId) {
    pageContents.forEach(page => page.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    
    const targetPage = document.getElementById(pageId);
    if (targetPage) targetPage.classList.add('active');
    
    const targetNav = document.querySelector(`.nav-item[data-page="${pageId}"]`);
    if (targetNav) targetNav.classList.add('active');
    
    if (pageTitle && pageTitles[pageId]) pageTitle.textContent = pageTitles[pageId];
    if (window.innerWidth <= 768) sidebar.classList.add('collapsed');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  navItems.forEach(item => {
    item.addEventListener('click', function(e) {
      e.preventDefault();
      const pageId = this.getAttribute('data-page');
      if (pageId) navigateToPage(pageId);
    });
  });

  // ============================================================
  // PARTE 2: DADOS REAIS (API BACKEND)
  // ============================================================

  // Configuração do Header com Token
  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  };

  // --- CARREGAR DADOS DO PROFESSOR E LISTAS ---
  async function loadData() {
    try {
        // A. Perfil
        const perfilRes = await fetch(`${API_URL}/professor/perfil`, { headers });
        if (perfilRes.ok) {
            const perfil = await perfilRes.json();
            document.getElementById('user-name').textContent = perfil.nome;
            document.getElementById('user-email').textContent = perfil.email;
            document.getElementById('user-initials').textContent = perfil.nome.substring(0, 2).toUpperCase();
            
            // Popula selects de disciplina
            populateSelects('disciplina-select', perfil.disciplinas, null);       // Form Nota
            populateSelects('disciplina-falta-select', perfil.disciplinas, null); // Form Falta
        } else if (perfilRes.status === 401) {
            logout();
        }

        // B. Lista de Alunos
        const alunosRes = await fetch(`${API_URL}/professor/alunos`, { headers });
        if (alunosRes.ok) {
            const alunos = await alunosRes.json();

            if(document.getElementById('stat-total-alunos')) {
                document.getElementById('stat-total-alunos').textContent = alunos.length;
            }

            // Popula selects de aluno
            populateSelects('aluno-select', alunos, 'ra');       
            populateSelects('aluno-falta-select', alunos, 'ra');
            
            // Popula selects de aluno
            populateSelects('aluno-select', alunos, 'ra');       // Form Nota
            populateSelects('aluno-falta-select', alunos, 'ra'); // Form Falta

            // Popula Tabela de Alunos (se estiver na tela)
            const tbody = document.getElementById('alunos-table-body');
            if (tbody) {
                tbody.innerHTML = '';
                alunos.forEach(aluno => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${aluno.ra}</td>
                        <td><strong>${aluno.nome_completo}</strong></td>
                        <td>${aluno.email || '-'}</td>
                        <td>${aluno.turma_id || '-'}</td>
                        <td><a href="#" class="link-action">Ver Detalhes</a></td>
                    `;
                    tbody.appendChild(tr);
                });
            }
        }
    } catch (e) {
        console.error("Erro de conexão:", e);
    }
  }

  // Função auxiliar para selects
  function populateSelects(elementId, data, valueKey) {
    const select = document.getElementById(elementId);
    if (!select) return;
    select.innerHTML = '<option value="">Selecione...</option>';
    data.forEach(item => {
        const option = document.createElement('option');
        option.value = valueKey ? item[valueKey] : item;
        option.textContent = valueKey ? `${item.nome_completo} (RA: ${item.ra})` : item;
        select.appendChild(option);
    });
  }

  loadData();

  // --- CADASTRO DE ALUNO (REAL) ---
  const formCadastrarAluno = document.getElementById('form-cadastrar-aluno');
  if (formCadastrarAluno) {
    formCadastrarAluno.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const formData = {
        nome_completo: document.getElementById('nome').value,
        ra: document.getElementById('cpf').value, // Usando campo CPF como RA provisório se não tiver campo RA
        data_nascimento: document.getElementById('data_nascimento').value,
        email: document.getElementById('email').value,
        turma_id: "TADS2024" // Valor fixo ou criar campo no HTML
      };

      try {
        const res = await fetch(`${API_URL}/professor/aluno`, {
            method: 'POST',
            headers,
            body: JSON.stringify(formData)
        });
        
        if (res.ok) {
            showAlert('alert-cadastro', 'Aluno cadastrado com sucesso!', 'success');
            formCadastrarAluno.reset();
            loadData(); // Recarrega listas
        } else {
            const data = await res.json();
            showAlert('alert-cadastro', 'Erro: ' + data.msg, 'error');
        }
      } catch (e) {
        showAlert('alert-cadastro', 'Erro de conexão.', 'error');
      }
    });
  }

  // --- LANÇAR NOTAS (REAL) ---
  const formLancarNota = document.getElementById('form-lancar-nota');
  if (formLancarNota) {
    formLancarNota.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const dados = {
          aluno_ra: document.getElementById('aluno-select').value,
          disciplina_nome: document.getElementById('disciplina-select').value,
          tipo_avaliacao: "Prova 1", // Pode criar input no HTML pra isso
          valor: document.getElementById('nota').value
      };

      try {
          const res = await fetch(`${API_URL}/professor/notas/lancar`, {
             method: 'POST', headers, body: JSON.stringify(dados)
          });
          
          if (res.ok) {
              showFeedbackNota('Nota salva com sucesso!', 'success');
              setTimeout(() => formLancarNota.reset(), 2000);
          } else {
              const d = await res.json();
              showFeedbackNota('Erro: ' + d.msg, 'danger');
          }
      } catch (e) {
          showFeedbackNota('Erro de conexão', 'danger');
      }
    });
  }

  // --- UTILITÁRIOS VISUAIS ---
  function showFeedbackNota(message, type) {
    const feedbackNota = document.getElementById('feedback-nota');
    if (feedbackNota) {
      feedbackNota.textContent = message;
      feedbackNota.className = `alert ${type}`;
      feedbackNota.classList.remove('hidden');
    }
  }

  function showAlert(containerId, message, type) {
    const container = document.getElementById(containerId);
    if (container) {
      container.innerHTML = `<div class="alert ${type}">${message}</div>`;
      setTimeout(() => container.innerHTML = '', 5000);
    }
  }

  // --- LOGOUT ---
  const logoutBtn = document.querySelector('.nav-item.logout');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', function(e) {
      e.preventDefault();
      localStorage.removeItem('token');
      localStorage.removeItem('usuario');
      window.location.href = 'index.html';
    });
  }
  
  function logout() {
      localStorage.removeItem('token');
      window.location.href = 'professor-login.html';
  }

  console.log('✅ Portal do Professor ONLINE!');
});
