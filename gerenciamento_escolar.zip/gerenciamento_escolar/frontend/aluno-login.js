const API_URL = "http://127.0.0.1:5000/api";

document.getElementById('loginForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  
  const ra = document.getElementById('ra').value;
  const senha = document.getElementById('senha').value;
  const alertContainer = document.getElementById('alert-container');
  const btn = document.querySelector('.btn-primary'); // Ajuste se seu botão tiver outra classe

  // Limpa alertas anteriores
  if (alertContainer) alertContainer.innerHTML = '';
  
  // Feedback visual
  const originalBtnText = btn.innerHTML;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Entrando...';
  btn.disabled = true;

  try {
    const response = await fetch(`${API_URL}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ 
        username: ra, 
        senha: senha 
      })
    });

    const data = await response.json();

    if (response.ok) {
      // SUCESSO!
      localStorage.setItem('token', data.token);
      localStorage.setItem('usuario', JSON.stringify({
        nome: data.nome,
        tipo: data.tipo_usuario
      }));

      window.location.href = 'aluno.html';
    } else {
      throw new Error(data.msg || 'Erro ao fazer login');
    }

  } catch (error) {
    if (alertContainer) {
      alertContainer.innerHTML = `
        <div class="alert error" style="color: #ff6b6b; background: rgba(255,0,0,0.1); padding: 10px; border-radius: 5px; margin-bottom: 15px; text-align: center;">
          <i class="fas fa-exclamation-circle"></i> ${error.message}
        </div>
      `;
    } else {
      alert(error.message);
    }
    btn.innerHTML = originalBtnText;
    btn.disabled = false;
  }
});
