const API_URL = "http://127.0.0.1:5000/api";

document.getElementById('loginForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  
  const email = document.getElementById('email').value; // Geralmente professor usa email
  const senha = document.getElementById('senha').value;
  const alertContainer = document.getElementById('alert-container');
  const btn = document.querySelector('.btn-primary');

  if (alertContainer) alertContainer.innerHTML = '';
  
  const originalBtnText = btn.innerHTML;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Entrando...';
  btn.disabled = true;

  try {
    const response = await fetch(`${API_URL}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        username: email, 
        senha: senha 
      })
    });

    const data = await response.json();

    if (response.ok) {
      // SEGURANÇA EXTRA: Verifica se é professor mesmo
      if (data.tipo_usuario !== 'professor') {
        throw new Error("Esta conta não tem permissão de Professor.");
      }

      localStorage.setItem('token', data.token);
      localStorage.setItem('usuario', JSON.stringify({
        nome: data.nome,
        tipo: data.tipo_usuario
      }));

      window.location.href = 'professor.html';
    } else {
      throw new Error(data.msg || 'Erro ao fazer login');
    }

  } catch (error) {
    if (alertContainer) {
      alertContainer.innerHTML = `
        <div class="alert error" style="color: #ff6b6b; background: rgba(255,0,0,0.1); padding: 10px; border-radius: 5px; margin-bottom: 15px; text-align: center;">
          <i class="fas fa-exclamation-circle"></i> ${error.message}
        </div>
      `;
    } else {
      alert(error.message);
    }
    btn.innerHTML = originalBtnText;
    btn.disabled = false;
  }
});
