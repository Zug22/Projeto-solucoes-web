// ========== PORTAL DO ALUNO - NAVEGAÇÃO E INTERATIVIDADE ==========

document.addEventListener('DOMContentLoaded', function() {
  
  // ========== SISTEMA DE TEMA (CLARO/ESCURO) ==========
  function initTheme() {
    // Verificar se há preferência salva, senão usar preferência do sistema
    const savedTheme = localStorage.getItem('theme');
    let theme = savedTheme;
    
    if (!savedTheme) {
      // Detectar preferência do sistema (tema escuro do navegador)
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      theme = prefersDark ? 'dark' : 'light';
    }
    
    document.documentElement.setAttribute('data-theme', theme);
    updateThemeIcon(theme);
  }

  function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeIcon(newTheme);
  }

  function updateThemeIcon(theme) {
    const themeIcon = document.getElementById('themeIcon');
    if (themeIcon) {
      themeIcon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
  }

  // Inicializar tema
  initTheme();

  // Toggle de tema
  const themeToggle = document.getElementById('themeToggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', toggleTheme);
  }
  
  // ========== MENU TOGGLE (Mobile) ==========
  const menuToggle = document.getElementById('menuToggle');
  const sidebar = document.getElementById('sidebar');
  
  if (menuToggle) {
    menuToggle.addEventListener('click', function() {
      sidebar.classList.toggle('collapsed');
    });
  }

  // ========== NAVEGAÇÃO ENTRE PÁGINAS ==========
  const navItems = document.querySelectorAll('.nav-item[data-page], .quick-card[data-page]');
  const pageContents = document.querySelectorAll('.page-content');
  const pageTitle = document.getElementById('pageTitle');
  
  // Títulos das páginas
  const pageTitles = {
    dashboard: 'Dashboard',
    notas: 'Notas e Avaliações',
    faltas: 'Controle de Faltas',
    desempenho: 'Meu Desempenho',
    horarios: 'Horários de Aula',
    comunicados: 'Comunicados'
  };

  // Variável para controlar inicialização dos gráficos
  let chartsInitialized = false;

  // Função para mudar de página
  function navigateToPage(pageId) {
    // Remover active de todas as páginas
    pageContents.forEach(page => {
      page.classList.remove('active');
    });
    
    // Remover active de todos os nav items
    document.querySelectorAll('.nav-item').forEach(item => {
      item.classList.remove('active');
    });
    
    // Ativar página selecionada
    const targetPage = document.getElementById(pageId);
    if (targetPage) {
      targetPage.classList.add('active');
    }
    
    // Ativar nav item correspondente
    const targetNav = document.querySelector(`.nav-item[data-page="${pageId}"]`);
    if (targetNav) {
      targetNav.classList.add('active');
    }
    
    // Atualizar título
    if (pageTitle && pageTitles[pageId]) {
      pageTitle.textContent = pageTitles[pageId];
    }
    
    // Inicializar gráficos quando a página de desempenho for acessada
    if (pageId === 'desempenho' && !chartsInitialized) {
      setTimeout(() => {
        initCharts();
        chartsInitialized = true;
      }, 100);
    }
    
    // Fechar sidebar no mobile após clicar
    if (window.innerWidth <= 768) {
      sidebar.classList.add('collapsed');
    }
    
    // Scroll para o topo
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Adicionar event listeners
  navItems.forEach(item => {
    item.addEventListener('click', function(e) {
      e.preventDefault();
      const pageId = this.getAttribute('data-page');
      if (pageId) {
        navigateToPage(pageId);
      }
    });
  });

  // ========== FILTROS DE FALTAS ==========
  const filterButtons = document.querySelectorAll('.filter-btn');
  
  filterButtons.forEach(btn => {
    btn.addEventListener('click', function() {
      // Remover active de todos
      filterButtons.forEach(b => b.classList.remove('active'));
      // Adicionar active no clicado
      this.classList.add('active');
      
      // Aqui você pode adicionar lógica para filtrar os dados
      // quando o backend for integrado
      console.log('Filtro selecionado:', this.textContent);
    });
  });

  // ========== INICIALIZAR GRÁFICOS ==========
  function initCharts() {
    // Dados mockados para os gráficos
    const mockEvolutionData = {
      labels: ['1º Bimestre', '2º Bimestre', '3º Bimestre', '4º Bimestre'],
      datasets: [{
        label: 'Média Geral',
        data: [7.5, 8.2, 8.0, 8.5],
        borderColor: '#3b82f6',
        backgroundColor: 'rgba(37, 99, 235, 0.1)',
        borderWidth: 3,
        fill: true,
        tension: 0.4,
        pointRadius: 6,
        pointBackgroundColor: '#3b82f6',
        pointBorderColor: '#fff',
        pointBorderWidth: 2
      }]
    };

    const mockDisciplineData = {
      labels: ['Matemática', 'Português', 'Física', 'Química', 'História', 'Geografia'],
      datasets: [{
        label: 'Média por Disciplina',
        data: [8.5, 7.8, 6.8, 8.9, 7.5, 8.2],
        backgroundColor: [
          'rgba(37, 99, 235, 0.8)',
          'rgba(59, 130, 246, 0.8)',
          'rgba(16, 185, 129, 0.8)',
          'rgba(245, 158, 11, 0.8)',
          'rgba(239, 68, 68, 0.8)',
          'rgba(96, 165, 250, 0.8)'
        ],
        borderColor: [
          '#2563eb',
          '#3b82f6',
          '#10b981',
          '#f59e0b',
          '#ef4444',
          '#60a5fa'
        ],
        borderWidth: 2,
        borderRadius: 8
      }]
    };

    // Configuração comum para os gráficos
    const commonOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: 'top',
          labels: {
            font: {
              family: 'Poppins',
              size: 12,
              weight: 500
            },
            color: 'var(--text-dark)',
            padding: 15,
            usePointStyle: true
          }
        },
        tooltip: {
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          padding: 12,
          titleFont: {
            family: 'Poppins',
            size: 14,
            weight: 600
          },
          bodyFont: {
            family: 'Poppins',
            size: 13
          },
          borderColor: '#3b82f6',
          borderWidth: 1,
          cornerRadius: 8,
          displayColors: true
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          max: 10,
          ticks: {
            font: {
              family: 'Poppins',
              size: 11
            },
            color: 'var(--text-secondary)'
          },
          grid: {
            color: 'var(--border-color)',
            drawBorder: false
          }
        },
        x: {
          ticks: {
            font: {
              family: 'Poppins',
              size: 11
            },
            color: 'var(--text-secondary)'
          },
          grid: {
            display: false
          }
        }
      }
    };

    // Gráfico de Evolução das Notas (Line Chart)
    const evolutionCtx = document.getElementById('evolutionChart');
    if (evolutionCtx) {
      new Chart(evolutionCtx, {
        type: 'line',
        data: mockEvolutionData,
        options: {
          ...commonOptions,
          plugins: {
            ...commonOptions.plugins,
            title: {
              display: false
            }
          }
        }
      });
    }

    // Gráfico de Desempenho por Disciplina (Bar Chart)
    const disciplineCtx = document.getElementById('disciplineChart');
    if (disciplineCtx) {
      new Chart(disciplineCtx, {
        type: 'bar',
        data: mockDisciplineData,
        options: {
          ...commonOptions,
          plugins: {
            ...commonOptions.plugins,
            title: {
              display: false
            }
          }
        }
      });
    }
  }

  // Função auxiliar para obter iniciais do nome
  function getInitials(name) {
    if (!name) return 'AA';
    const parts = name.split(' ');
    if (parts.length >= 2) {
      return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  }
  
  function updateStudentInfo(aluno) {
    const userNameEl = document.getElementById('user-name');
    const userRAEl = document.getElementById('user-ra');
    const userInitialsEl = document.getElementById('user-initials');
    
    if (userNameEl && aluno.nome) {
      userNameEl.textContent = aluno.nome;
    }
    
    if (userRAEl && aluno.ra) {
      userRAEl.textContent = `RA: ${aluno.ra}`;
    }
    
    if (userInitialsEl && aluno.nome) {
      userInitialsEl.textContent = getInitials(aluno.nome);
    }
  }

  // ========== CARREGAR DADOS DO ALUNO ==========
  function loadStudentData() {
    // Tentar carregar do localStorage primeiro
    const alunoData = localStorage.getItem('aluno');
    
    if (alunoData) {
      try {
        const aluno = JSON.parse(alunoData);
        updateStudentInfo(aluno);
        return;
      } catch (e) {
        console.error('Erro ao parsear dados do aluno:', e);
      }
    }
    
    // Se não houver dados, usar dados mock (modo desenvolvimento)
    const alunoMock = {
      id: 1,
      ra: '2024001234',
      nome: 'João da Silva',
      email: 'joao.silva@escola.com'
    };
    
    updateStudentInfo(alunoMock);
    localStorage.setItem('aluno', JSON.stringify(alunoMock));
    console.log('⚠️ Modo desenvolvimento: usando dados mock');
  }

  // Carregar dados do aluno ao iniciar
  loadStudentData();

  // ========== TRATAR CLIQUE EM MENSAGENS ==========
  const messageCards = document.querySelectorAll('.message-card');
  
  messageCards.forEach(card => {
    card.addEventListener('click', function(e) {
      // Não fazer nada se clicou no link "Ler mais"
      if (e.target.closest('.message-link')) {
        return;
      }
      
      // Marcar como lida (quando backend for integrado)
      if (this.classList.contains('unread')) {
        this.classList.remove('unread');
        // Aqui você pode fazer uma chamada ao backend
        console.log('Mensagem marcada como lida');
      }
    });
  });

  // ========== RESPONSIVIDADE - FECHAR SIDEBAR AO CLICAR FORA ==========
  document.addEventListener('click', function(e) {
    if (window.innerWidth <= 768) {
      // Se clicou fora da sidebar e ela está aberta, fechar
      if (!sidebar.contains(e.target) && !menuToggle.contains(e.target)) {
        if (!sidebar.classList.contains('collapsed')) {
          sidebar.classList.add('collapsed');
        }
      }
    }
  });

  // ========== ANIMAÇÕES AO SCROLL ==========
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };

  const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, observerOptions);

  // Observar elementos para animação
  document.querySelectorAll('.stat-card, .quick-card, .activity-item').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    observer.observe(el);
  });

  // ========== LOGOUT ==========
  const logoutBtn = document.querySelector('.nav-item.logout');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', function(e) {
      e.preventDefault();
      // Limpar dados da sessão (quando backend for integrado)
      // window.location.href = 'index.html';
      
      // Por enquanto, apenas redireciona
      if (confirm('Deseja realmente sair?')) {
        window.location.href = 'index.html';
      }
    });
  }

  console.log('✅ Portal do Aluno inicializado com sucesso!');
});

