from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt
from bson.objectid import ObjectId
from database import COLLECTIONS
from functools import wraps

professor_bp = Blueprint('professor', __name__)

# Decorator para verificar se o usuário é um professor
def professor_required():
    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            claims = get_jwt()
            if claims.get('tipo_usuario') != 'professor':
                return jsonify({"msg": "Acesso negado: Requer perfil de Professor"}), 403
            return fn(*args, **kwargs)
        return decorator
    return wrapper

# Rota: /api/professor/perfil
@professor_bp.route('/professor/perfil', methods=['GET'])
@jwt_required()
@professor_required()
def get_perfil():
    claims = get_jwt()
    professor_id = claims.get('referencia_id')
    
    professor = COLLECTIONS["professores"].find_one({"_id": ObjectId(professor_id)})
    
    if not professor:
        return jsonify({"msg": "Professor não encontrado"}), 404

    # Converte ObjectId para string para serialização JSON
    professor['_id'] = str(professor['_id'])
    
    return jsonify({
        "nome": professor.get('nome_completo'),
        "email": professor.get('email'),
        "disciplinas": professor.get('disciplinas', [])
    }), 200

# Rota: /api/professor/alunos
@professor_bp.route('/professor/alunos', methods=['GET'])
@jwt_required()
@professor_required()
def get_alunos():
    # Retorna todos os alunos cadastrados (simulação de lista completa)
    alunos = list(COLLECTIONS["alunos"].find({}, {"_id": 0, "nome_completo": 1, "ra": 1, "email": 1, "turma_id": 1}))
    
    return jsonify(alunos), 200

# Rota: /api/professor/aluno (Cadastrar Aluno)
@professor_bp.route('/professor/aluno', methods=['POST'])
@jwt_required()
@professor_required()
def cadastrar_aluno():
    data = request.get_json()
    
    # Validação básica
    required_fields = ['nome_completo', 'ra', 'data_nascimento', 'turma_id']
    if not all(field in data for field in required_fields):
        return jsonify({"msg": "Campos obrigatórios ausentes"}), 400
        
    # Verifica se o RA já existe
    if COLLECTIONS["alunos"].find_one({"ra": data['ra']}):
        return jsonify({"msg": "RA já cadastrado"}), 409

    try:
        # 1. Insere o novo aluno
        aluno_data = {
            "ra": data['ra'],
            "nome_completo": data['nome_completo'],
            "data_nascimento": data['data_nascimento'],
            "email": data.get('email'),
            "turma_id": data['turma_id']
        }
        result = COLLECTIONS["alunos"].insert_one(aluno_data)
        novo_aluno_id = result.inserted_id
        
        # 2. Cria um usuário de login padrão para o aluno (senha padrão: "aluno123")
        from werkzeug.security import generate_password_hash
        COLLECTIONS["usuarios"].insert_one({
            "username": data['ra'],
            "senha_hash": generate_password_hash("aluno123"),
            "tipo_usuario": "aluno",
            "referencia_id": novo_aluno_id
        })
        
        return jsonify({"msg": "Aluno cadastrado com sucesso", "aluno_id": str(novo_aluno_id)}), 201
        
    except Exception as e:
        return jsonify({"msg": f"Erro ao cadastrar aluno: {str(e)}"}), 500

# Rota: /api/professor/notas/lancar
@professor_bp.route('/professor/notas/lancar', methods=['POST'])
@jwt_required()
@professor_required()
def lancar_nota():
    data = request.get_json()
    
    required_fields = ['aluno_ra', 'disciplina_nome', 'tipo_avaliacao', 'valor']
    if not all(field in data for field in required_fields):
        return jsonify({"msg": "Campos obrigatórios ausentes"}), 400
        
    try:
        aluno = COLLECTIONS["alunos"].find_one({"ra": data['aluno_ra']})
        if not aluno:
            return jsonify({"msg": "Aluno não encontrado"}), 404
            
        disciplina = COLLECTIONS["disciplinas"].find_one({"nome": data['disciplina_nome']})
        if not disciplina:
            return jsonify({"msg": "Disciplina não encontrada"}), 404
            
        nota_data = {
            "aluno_id": aluno['_id'],
            "disciplina_id": disciplina['_id'],
            "tipo_avaliacao": data['tipo_avaliacao'],
            "valor": float(data['valor']),
            "data_lancamento": data.get('data_lancamento', 'Data não informada')
        }
        
        COLLECTIONS["notas"].insert_one(nota_data)
        
        return jsonify({"msg": "Nota lançada com sucesso"}), 201
        
    except ValueError:
        return jsonify({"msg": "Valor da nota inválido"}), 400
    except Exception as e:
        return jsonify({"msg": f"Erro ao lançar nota: {str(e)}"}), 500

# Rota: /api/professor/faltas/registrar
@professor_bp.route('/professor/faltas/registrar', methods=['POST'])
@jwt_required()
@professor_required()
def registrar_falta():
    data = request.get_json()
    
    required_fields = ['aluno_ra', 'disciplina_nome', 'data', 'aulas_perdidas']
    if not all(field in data for field in required_fields):
        return jsonify({"msg": "Campos obrigatórios ausentes"}), 400
        
    try:
        aluno = COLLECTIONS["alunos"].find_one({"ra": data['aluno_ra']})
        if not aluno:
            return jsonify({"msg": "Aluno não encontrado"}), 404
            
        disciplina = COLLECTIONS["disciplinas"].find_one({"nome": data['disciplina_nome']})
        if not disciplina:
            return jsonify({"msg": "Disciplina não encontrada"}), 404
            
        falta_data = {
            "aluno_id": aluno['_id'],
            "disciplina_id": disciplina['_id'],
            "data": data['data'],
            "aulas_perdidas": int(data['aulas_perdidas']),
            "justificada": False,
            "justificativa_texto": ""
        }
        
        COLLECTIONS["faltas"].insert_one(falta_data)
        
        return jsonify({"msg": "Falta registrada com sucesso"}), 201
        
    except ValueError:
        return jsonify({"msg": "Número de aulas perdidas inválido"}), 400
    except Exception as e:
        return jsonify({"msg": f"Erro ao registrar falta: {str(e)}"}), 500

# Rota: /api/professor/faltas/justificar/<falta_id> (Aprovar Justificativa)
@professor_bp.route('/professor/faltas/justificar/<falta_id>', methods=['PUT'])
@jwt_required()
@professor_required()
def aprovar_justificativa(falta_id):
    data = request.get_json()
    
    if 'justificada' not in data:
        return jsonify({"msg": "O campo 'justificada' é obrigatório"}), 400
        
    try:
        result = COLLECTIONS["faltas"].update_one(
            {"_id": ObjectId(falta_id)},
            {"$set": {"justificada": bool(data['justificada']), "justificativa_texto": data.get('justificativa_texto', '')}}
        )
        
        if result.matched_count == 0:
            return jsonify({"msg": "Falta não encontrada"}), 404
            
        return jsonify({"msg": "Status de justificativa atualizado com sucesso"}), 200
        
    except Exception as e:
        return jsonify({"msg": f"Erro ao atualizar justificativa: {str(e)}"}), 500
