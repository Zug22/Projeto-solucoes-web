from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import timedelta
from bson.objectid import ObjectId
from database import COLLECTIONS # Importa as coleções do MongoDB

auth_bp = Blueprint('auth', __name__)

# Função auxiliar para criar um usuário inicial (apenas para demonstração)
def create_initial_users():
    usuarios = COLLECTIONS["usuarios"]
    alunos = COLLECTIONS["alunos"]
    professores = COLLECTIONS["professores"]

    # Verifica se já existem usuários
    if usuarios.count_documents({}) > 0:
        return

    # 1. Aluno de Exemplo
    aluno_id = alunos.insert_one({
        "ra": "2024001234",
        "nome_completo": "João da Silva",
        "email": "joao.silva@escola.com",
        "turma_id": "TADS2024"
    }).inserted_id

    usuarios.insert_one({
        "username": "2024001234", # RA
        "senha_hash": generate_password_hash("aluno123"),
        "tipo_usuario": "aluno",
        "referencia_id": aluno_id
    })

    # 2. Professor de Exemplo
    professor_id = professores.insert_one({
        "nome_completo": "Professor Admin",
        "email": "professor@edugestor.com",
        "disciplinas": ["Matemática", "Física"]
    }).inserted_id

    usuarios.insert_one({
        "username": "professor@edugestor.com", # Email
        "senha_hash": generate_password_hash("prof123"),
        "tipo_usuario": "professor",
        "referencia_id": professor_id
    })

    print("Usuários iniciais criados (Aluno: 2024001234/aluno123, Professor: professor@edugestor.com/prof123)")

# Rota de Login
@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    senha = data.get('senha')

    if not username or not senha:
        return jsonify({"msg": "RA/Email e senha são obrigatórios"}), 400

    usuario = COLLECTIONS["usuarios"].find_one({"username": username})

    if usuario and check_password_hash(usuario['senha_hash'], senha):
        # Busca o nome do usuário para incluir no token/resposta
        if usuario['tipo_usuario'] == 'aluno':
            perfil = COLLECTIONS["alunos"].find_one({"_id": usuario['referencia_id']})
            nome = perfil.get('nome_completo')
        elif usuario['tipo_usuario'] == 'professor':
            perfil = COLLECTIONS["professores"].find_one({"_id": usuario['referencia_id']})
            nome = perfil.get('nome_completo')
        else:
            nome = "Usuário Desconhecido"

        # Cria o token de acesso
        access_token = create_access_token(
            identity=str(usuario['_id']),
            expires_delta=timedelta(hours=1),
            additional_claims={
                "tipo_usuario": usuario['tipo_usuario'],
                "referencia_id": str(usuario['referencia_id']),
                "nome": nome
            }
        )
        
        return jsonify({
            "token": access_token,
            "tipo_usuario": usuario['tipo_usuario'],
            "nome": nome
        }), 200
    else:
        return jsonify({"msg": "Credenciais inválidas"}), 401

# Chama a função para criar usuários iniciais ao carregar o blueprint
create_initial_users()
