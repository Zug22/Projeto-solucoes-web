from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt
from bson.objectid import ObjectId
from database import COLLECTIONS
from functools import wraps

aluno_bp = Blueprint('aluno', __name__)

# Decorator para verificar se o usuário é um aluno
def aluno_required():
    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            claims = get_jwt()
            if claims.get('tipo_usuario') != 'aluno':
                return jsonify({"msg": "Acesso negado: Requer perfil de Aluno"}), 403
            return fn(*args, **kwargs)
        return decorator
    return wrapper

# Função auxiliar para popular dados de exemplo (Notas e Faltas)
def populate_aluno_data():
    alunos = COLLECTIONS["alunos"]
    notas = COLLECTIONS["notas"]
    faltas = COLLECTIONS["faltas"]
    disciplinas = COLLECTIONS["disciplinas"]

    # Verifica se o aluno de exemplo existe
    aluno_joao = alunos.find_one({"ra": "2024001234"})
    if not aluno_joao:
        return

    # Popula Disciplinas (se não existirem)
    if disciplinas.count_documents({}) == 0:
        disciplinas.insert_many([
            {"nome": "Matemática"},
            {"nome": "Português"},
            {"nome": "Física"},
            {"nome": "Química"}
        ])
    
    # Busca IDs das disciplinas
    disc_mat = disciplinas.find_one({"nome": "Matemática"})['_id']
    disc_port = disciplinas.find_one({"nome": "Português"})['_id']
    disc_fis = disciplinas.find_one({"nome": "Física"})['_id']
    
    # Popula Notas (se não existirem)
    if notas.count_documents({"aluno_id": aluno_joao['_id']}) == 0:
        notas.insert_many([
            {"aluno_id": aluno_joao['_id'], "disciplina_id": disc_mat, "tipo_avaliacao": "Nota 1", "valor": 8.5, "data_lancamento": "2025-03-15"},
            {"aluno_id": aluno_joao['_id'], "disciplina_id": disc_mat, "tipo_avaliacao": "Nota 2", "valor": 9.0, "data_lancamento": "2025-04-20"},
            {"aluno_id": aluno_joao['_id'], "disciplina_id": disc_port, "tipo_avaliacao": "Nota 1", "valor": 7.5, "data_lancamento": "2025-03-10"},
            {"aluno_id": aluno_joao['_id'], "disciplina_id": disc_port, "tipo_avaliacao": "Nota 2", "valor": 8.0, "data_lancamento": "2025-04-15"},
        ])

    # Popula Faltas (se não existirem)
    if faltas.count_documents({"aluno_id": aluno_joao['_id']}) == 0:
        faltas.insert_many([
            {"aluno_id": aluno_joao['_id'], "disciplina_id": disc_mat, "data": "2025-03-01", "aulas_perdidas": 2, "justificada": False, "justificativa_texto": ""},
            {"aluno_id": aluno_joao['_id'], "disciplina_id": disc_fis, "data": "2025-03-05", "aulas_perdidas": 2, "justificada": True, "justificativa_texto": "Atestado médico"}
        ])

    # Popula Comunicados (se não existirem)
    comunicados = COLLECTIONS["comunicados"]
    if comunicados.count_documents({}) == 0:
        comunicados.insert_many([
            {"titulo": "Reunião de Pais", "conteudo": "A reunião de pais e mestres será no dia 01/12.", "data": "2025-11-20"},
            {"titulo": "Fechamento de Notas", "conteudo": "Prazo final para entrega de trabalhos: 25/11.", "data": "2025-11-15"}
        ])

    print("Dados de exemplo do aluno populados.")

# Rota: /api/aluno/perfil
@aluno_bp.route('/aluno/perfil', methods=['GET'])
@jwt_required()
@aluno_required()
def get_perfil():
    claims = get_jwt()
    aluno_id = claims.get('referencia_id')
    
    aluno = COLLECTIONS["alunos"].find_one({"_id": ObjectId(aluno_id)})
    
    if not aluno:
        return jsonify({"msg": "Aluno não encontrado"}), 404

    # Converte ObjectId para string para serialização JSON
    aluno['_id'] = str(aluno['_id'])
    
    return jsonify({
        "nome": aluno.get('nome_completo'),
        "ra": aluno.get('ra'),
        "turma": aluno.get('turma_id'),
        "email": aluno.get('email')
    }), 200

# Rota: /api/aluno/dashboard
@aluno_bp.route('/aluno/dashboard', methods=['GET'])
@jwt_required()
@aluno_required()
def get_dashboard():
    claims = get_jwt()
    aluno_id = ObjectId(claims.get('referencia_id'))
    
    # 1. Média Geral (Simulação)
    # Em um sistema real, isso seria um cálculo complexo
    media_geral = 8.5 
    
    # 2. Frequência (Simulação)
    frequencia = 92
    
    # 3. Disciplinas Ativas (Contagem de disciplinas com notas)
    disciplinas_ativas = COLLECTIONS["notas"].distinct("disciplina_id", {"aluno_id": aluno_id})
    
    # 4. Próxima Avaliação (Simulação)
    proxima_avaliacao = "Matemática (3 dias)"
    
    return jsonify({
        "media_geral": media_geral,
        "frequencia": f.format(frequencia),
        "disciplinas_ativas": len(disciplinas_ativas),
        "proxima_avaliacao": proxima_avaliacao
    }), 200

# Rota: /api/aluno/notas
@aluno_bp.route('/aluno/notas', methods=['GET'])
@jwt_required()
@aluno_required()
def get_notas():
    claims = get_jwt()
    aluno_id = ObjectId(claims.get('referencia_id'))
    
    # Agregação para buscar notas por disciplina
    pipeline = [
        {"$match": {"aluno_id": aluno_id}},
        {"$lookup": {
            "from": "disciplinas",
            "localField": "disciplina_id",
            "foreignField": "_id",
            "as": "disciplina_info"
        }},
        {"$unwind": "$disciplina_info"},
        {"$group": {
            "_id": "$disciplina_info.nome",
            "notas": {"$push": {"tipo": "$tipo_avaliacao", "valor": "$valor", "data": "$data_lancamento"}},
            "media": {"$avg": "$valor"}
        }},
        {"$project": {
            "_id": 0,
            "disciplina": "$_id",
            "notas": 1,
            "media": {"$round": ["$media", 1]}
        }}
    ]
    
    resultados = list(COLLECTIONS["notas"].aggregate(pipeline))
    
    # Adiciona situação (simulação)
    for res in resultados:
        res['situacao'] = "Aprovado" if res['media'] >= 7.0 else "Atenção"
        
    return jsonify(resultados), 200

# Rota: /api/aluno/faltas
@aluno_bp.route('/aluno/faltas', methods=['GET'])
@jwt_required()
@aluno_required()
def get_faltas():
    claims = get_jwt()
    aluno_id = ObjectId(claims.get('referencia_id'))
    
    # Busca faltas e faz lookup com a disciplina
    pipeline = [
        {"$match": {"aluno_id": aluno_id}},
        {"$lookup": {
            "from": "disciplinas",
            "localField": "disciplina_id",
            "foreignField": "_id",
            "as": "disciplina_info"
        }},
        {"$unwind": "$disciplina_info"},
        {"$project": {
            "_id": {"$toString": "$_id"},
            "disciplina": "$disciplina_info.nome",
            "data": 1,
            "aulas_perdidas": 1,
            "justificada": 1,
            "justificativa_texto": 1
        }}
    ]
    
    faltas = list(COLLECTIONS["faltas"].aggregate(pipeline))
    
    return jsonify(faltas), 200

# Rota: /api/aluno/faltas/justificar
@aluno_bp.route('/aluno/faltas/justificar', methods=['POST'])
@jwt_required()
@aluno_required()
def justificar_falta():
    claims = get_jwt()
    aluno_id = ObjectId(claims.get('referencia_id'))
    data = request.get_json()
    
    falta_id = data.get('falta_id')
    justificativa = data.get('justificativa')
    
    if not falta_id or not justificativa:
        return jsonify({"msg": "ID da falta e justificativa são obrigatórios"}), 400
        
    try:
        result = COLLECTIONS["faltas"].update_one(
            {"_id": ObjectId(falta_id), "aluno_id": aluno_id, "justificada": False},
            {"$set": {"justificada": True, "justificativa_texto": justificativa}}
        )
        
        if result.matched_count == 0:
            return jsonify({"msg": "Falta não encontrada, já justificada ou não pertence a este aluno"}), 404
            
        return jsonify({"msg": "Justificativa enviada com sucesso. Aguardando aprovação do professor."}), 200
        
    except Exception as e:
        return jsonify({"msg": f"Erro ao justificar falta: {str(e)}"}), 500

# Rota: /api/aluno/comunicados
@aluno_bp.route('/aluno/comunicados', methods=['GET'])
@jwt_required()
@aluno_required()
def get_comunicados():
    # Busca todos os comunicados (simples, sem filtro por turma/aluno)
    comunicados = list(COLLECTIONS["comunicados"].find({}, {"_id": 0}))
    
    return jsonify(comunicados), 200

# Popula dados de exemplo
populate_aluno_data()
