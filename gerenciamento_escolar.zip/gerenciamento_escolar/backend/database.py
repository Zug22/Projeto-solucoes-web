import os
from dotenv import load_dotenv
from pymongo import MongoClient

# Carrega variáveis de ambiente
load_dotenv()

# --- Configuração do MongoDB ---
MONGO_URI = os.getenv("MONGO_URI")
client = MongoClient(MONGO_URI)
db = client.get_database() # Pega o nome do DB da URI

# --- Estrutura de Coleções ---
COLLECTIONS = {
    "usuarios": db.usuarios,
    "alunos": db.alunos,
    "professores": db.professores,
    "disciplinas": db.disciplinas,
    "notas": db.notas,
    "faltas": db.faltas,
    "comunicados": db.comunicados
}
