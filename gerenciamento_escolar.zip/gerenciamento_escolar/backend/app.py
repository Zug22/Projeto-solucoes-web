import os
from dotenv import load_dotenv
from flask import Flask, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager

# Carrega variáveis
load_dotenv()

# --- Configuração do Flask ---
app = Flask(__name__)
CORS(app) 

# Configuração do JWT
app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY")
jwt = JWTManager(app)

# --- Rotas de Teste ---
@app.route('/', methods=['GET'])
def home():
    return jsonify({"message": "EduGestor Backend API está online!", "status": "ok"}), 200

# --- Tratamento de Erros JWT ---
@jwt.unauthorized_loader
def unauthorized_callback(callback):
    return jsonify({"msg": "Token de acesso ausente ou inválido."}), 401

@jwt.expired_token_loader
def expired_token_callback(jwt_header, jwt_payload):
    return jsonify({"msg": "Token de acesso expirado."}), 401

# --- Importação e Registro de Blueprints ---
# Agora isso funciona porque as rotas não importam mais nada DESTE arquivo
from routes.auth import auth_bp
from routes.aluno import aluno_bp
from routes.professor import professor_bp

app.register_blueprint(auth_bp, url_prefix='/api')
app.register_blueprint(aluno_bp, url_prefix='/api')
app.register_blueprint(professor_bp, url_prefix='/api')

if __name__ == '__main__':
    port = int(os.getenv("FLASK_RUN_PORT", 5000))
    app.run(debug=True, port=port)
